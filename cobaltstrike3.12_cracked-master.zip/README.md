# cobaltstrike3.12_cracked

Cracked Cobaltstrike3.12 Trial Version

原版： https://github.com/microidz/Cobaltstrike-Trial

校验：https://verify.cobaltstrike.com/

xor.bin：https://github.com/verctor/CS_xor64

破解记录：https://www.cnblogs.com/ssooking/p/9825917.html

## 变更

- 去除使用时间限制
- 去除listeners个数限制
- 去除后门特征指纹
- 添加xor.bin



## 关键文件

```bash
common/License.class
aggressor/dialogs/ListenerDialog.class
common/ArtifactUtils.class
server/ProfileEdits.class
resources/xor.bin
resources/xor64.bin
```

**sha256校验**

```bash
shasum -a 256 cobaltstrike.jar
89f67a4d790f39607569381aa25aaaafd92346024b857e41c941e3545984ee04  cobaltstrike.jar
```

![cs](cs.png)

## 参考

https://xz.aliyun.com/t/2170

https://www.bilibili.com/video/av34171888/

https://github.com/Lz1y/cobalt_strike_3.12_patch